# Dólar en Colombia
Dólar en Colombia es un plugin que te permite consultar el precio del dólar oficial en Colombia (TRM) del día y saber si subió o bajó el precio.  

https://chrome.google.com/webstore/detail/d%C3%B3lar-en-colombia/kfhfekhnikgjcoigcpimlocnmedaicpe
