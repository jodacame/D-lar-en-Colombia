OneSignal.init({
    appId: "808af8e4-7805-4b61-ae8f-805bc2a336b3",
    googleProjectNumber: "351046841699"
});